const cityInput = document.querySelector(".city-input");
const searchButton = document.querySelector(".search-btn");
const locationButton = document.querySelector(".location-btn");
const currentWeatherDiv = document.querySelector(".current-weather");
const weatherCardsDiv = document.querySelector(".weather-cards");
const loadingSpinner = document.getElementById("loading-spinner");
const errorMessageDiv = document.getElementById("error-message");
const languageSelector = document.querySelector(".language-selector");
const suggestionsDiv = document.querySelector(".suggestions"); // Suggestions div

const API_KEY = "YOUR_API_KEY"; // Replace with your OpenWeatherMap API key

const translations = {
    en: {
        title: "Weather Dashboard",
        placeholder: "E.g., New York, London, Tokyo",
        enterCity: "Enter a City Name",
        search: "Search",
        useCurrentLocation: "Use Current Location",
        temperature: "Temperature",
        wind: "Wind",
        humidity: "Humidity",
        fiveDayForecast: "5-Day Forecast",
        errorMessage: "An error occurred while fetching the weather data.",
        emptyCity: "Please enter a city name."
    },
    es: {
        title: "Panel Meteorológico",
        placeholder: "Ejemplo: Nueva York, Londres, Tokio",
        enterCity: "Ingrese un nombre de ciudad",
        search: "Buscar",
        useCurrentLocation: "Usar ubicación actual",
        temperature: "Temperatura",
        wind: "Viento",
        humidity: "Humedad",
        fiveDayForecast: "Pronóstico a 5 días",
        errorMessage: "Se produjo un error al obtener los datos meteorológicos.",
        emptyCity: "Por favor, ingrese un nombre de ciudad."
    },
    fr: {
        title: "Tableau de Bord Météorologique",
        placeholder: "Ex : New York, Londres, Tokyo",
        enterCity: "Entrez un nom de ville",
        search: "Rechercher",
        useCurrentLocation: "Utiliser la position actuelle",
        temperature: "Température",
        wind: "Vent",
        humidity: "Humidité",
        fiveDayForecast: "Prévisions sur 5 jours",
        errorMessage: "Une erreur s'est produite lors de la récupération des données météorologiques.",
        emptyCity: "Veuillez entrer un nom de ville."
    },
    hi: {
        title: "मौसम डैशबोर्ड",
        placeholder: "जैसे, न्यू यॉर्क, लंदन, टोक्यो",
        enterCity: "एक शहर का नाम दर्ज करें",
        search: "खोजें",
        useCurrentLocation: "वर्तमान स्थान का उपयोग करें",
        temperature: "तापमान",
        wind: "हवा",
        humidity: "नमी",
        fiveDayForecast: "5-दिन का पूर्वानुमान",
        errorMessage: "मौसम डेटा प्राप्त करते समय एक त्रुटि हुई।",
        emptyCity: "कृपया एक शहर का नाम दर्ज करें।"
    },
};

// Sample list of cities for suggestions
const cityList = ["New York", "London", "Tokyo", "Paris", "Berlin", "Madrid", "Delhi", "Mumbai", "São Paulo", "Cairo"];

// Create weather card HTML
const createWeatherCard = (cityName, weatherItem, index) => {
    if (index === 0) {
        return `<div class="details">
                    <h2>${cityName} (${weatherItem.dt_txt.split(" ")[0]})</h2>
                    <h6>${translations[languageSelector.value].temperature}: ${(weatherItem.main.temp - 273.15).toFixed(2)}°C</h6>
                    <h6>${translations[languageSelector.value].wind}: ${weatherItem.wind.speed} m/s</h6>
                    <h6>${translations[languageSelector.value].humidity}: ${weatherItem.main.humidity}%</h6>
                </div>
                <div class="icon">
                    <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@2x.png">
                    <h6>${weatherItem.weather[0].description}</h6>
                </div>`;
    } else {
        return `<li class="card">
                    <h3>${weatherItem.dt_txt.split(" ")[0]}</h3>
                    <h6>${translations[languageSelector.value].temperature}: ${(weatherItem.main.temp - 273.15).toFixed(2)}°C</h6>
                    <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@2x.png">
                </li>`;
    }
};

// Fetch weather details
const getWeatherDetails = async (city) => {
    const url = typeof city === "string"
        ? `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}`
        : `https://api.openweathermap.org/data/2.5/forecast?lat=${city.latitude}&lon=${city.longitude}&appid=${API_KEY}`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        if (data.cod === "200") {
            errorMessageDiv.style.display = "none";
            currentWeatherDiv.innerHTML = "";
            weatherCardsDiv.innerHTML = "";
            data.list.slice(0, 6).forEach((item, index) => {
                const html = createWeatherCard(data.city.name, item, index);
                if (index === 0) {
                    currentWeatherDiv.insertAdjacentHTML("beforeend", html);
                } else {
                    weatherCardsDiv.insertAdjacentHTML("beforeend", html);
                }
            });
        } else {
            showError(data.message);
        }
    } catch (error) {
        showError(translations[languageSelector.value].errorMessage);
    } finally {
        loadingSpinner.style.display = "none";
    }
};

// Show error messages
const showError = (message) => {
    errorMessageDiv.style.display = "block";
    errorMessageDiv.textContent = message;
};

// Update language based on selection
const updateLanguage = () => {
    document.title = translations[languageSelector.value].title;
    document.querySelector("h1").textContent = translations[languageSelector.value].title;
    document.querySelector(".weather-input h3").textContent = translations[languageSelector.value].enterCity;
    cityInput.placeholder = translations[languageSelector.value].placeholder;
    searchButton.textContent = translations[languageSelector.value].search;
    locationButton.textContent = translations[languageSelector.value].useCurrentLocation;
};

// Filter and display city suggestions
const filterCities = (input) => {
    const filter = input.toLowerCase();
    suggestionsDiv.innerHTML = ""; // Clear previous suggestions
    const filteredCities = cityList.filter(city => city.toLowerCase().startsWith(filter));
    filteredCities.forEach(city => {
        const suggestionItem = document.createElement("div");
        suggestionItem.textContent = city;
        suggestionItem.addEventListener("click", () => {
            cityInput.value = city; // Fill the input with the selected city
            suggestionsDiv.style.display = "none"; // Hide suggestions after selection
        });
        suggestionsDiv.appendChild(suggestionItem);
    });
    suggestionsDiv.style.display = filteredCities.length ? "block" : "none"; // Show suggestions if available
};

// Input event listener for city suggestions
cityInput.addEventListener("input", () => {
    const inputValue = cityInput.value.trim();
    if (inputValue) {
        filterCities(inputValue); // Call the filter function
    } else {
        suggestionsDiv.style.display = "none"; // Hide suggestions when input is empty
    }
});

// Search button click event
searchButton.addEventListener("click", () => {
    const city = cityInput.value.trim();
    if (city !== "") {
        loadingSpinner.style.display = "block";
        getWeatherDetails(city);
        suggestionsDiv.style.display = "none"; // Hide suggestions after search
    } else {
        showError(translations[languageSelector.value].emptyCity);
    }
});

// Geolocation button click event
locationButton.addEventListener("click", () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            const { latitude, longitude } = position.coords;
            loadingSpinner.style.display = "block";
            getWeatherDetails({ latitude, longitude });
        }, (error) => {
            showError("Unable to retrieve your location.");
        });
    } else {
        showError("Geolocation is not supported by this browser.");
    }
});

// Language selector change event
languageSelector.addEventListener("change", () => {
    updateLanguage(); // Update the language when selection changes
});

// Set default language
languageSelector.value = "en"; // Default to English
updateLanguage(); // Initialize language display
